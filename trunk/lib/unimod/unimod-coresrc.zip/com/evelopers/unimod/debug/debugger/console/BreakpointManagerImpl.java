/*
 * Copyright (c) 1999-2004 eVelopers Corporation. All rights reserved.
 *
 * This is open source software; you can use, redistribute and/or modify 
 * it under the terms of the Open Software Licence v 2.1 as published by the Open 
 * Source Initiative.
 *
 * You should have received a copy of the Open Software Licence along with this
 * application; if not, contact the Open Source Initiative (http://opensource.org).
 */
package com.evelopers.unimod.debug.debugger.console;

import com.evelopers.common.exception.CommonException;
import com.evelopers.unimod.debug.Params;
import com.evelopers.unimod.debug.debugger.BreakpointManager;
import com.evelopers.unimod.debug.protocol.position.Position;
import com.evelopers.unimod.runtime.ModelEngine;
import com.evelopers.unimod.runtime.context.StateMachineContext;

/**
 * @author vgurov
 */
public class BreakpointManagerImpl implements BreakpointManager {

    /* (non-Javadoc)
     * @see com.evelopers.unimod.runtime.EventProvider#init(com.evelopers.unimod.runtime.ModelEngine)
     */
    public void init(ModelEngine engine) throws CommonException {
        // TODO Auto-generated method stub

    }
    
    /* (non-Javadoc)
     * @see com.evelopers.unimod.runtime.EventProvider#dispose()
     */
    public void dispose() {
        // TODO Auto-generated method stub

    }
    
    /* (non-Javadoc)
     * @see com.evelopers.unimod.debug.debugger.BreakpointManager#z1(com.evelopers.unimod.runtime.context.StateMachineContext)
     */
    public void z1(StateMachineContext context) throws CommonException {
        context.getEventContext().setParameter(Params.Event.BREAKPOINTS, new Position[]{});
    }
    
}
