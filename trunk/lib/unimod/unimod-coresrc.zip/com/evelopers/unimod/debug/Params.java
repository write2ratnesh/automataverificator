/*
 *   Copyright (c) 1999-2004 eVelopers Corporation. All rights reserved.
 *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA.
 */
package com.evelopers.unimod.debug;

public interface Params {

    public interface Event {
        public static final String BREAKPOINTS = "BREAKPOINTS";
        public static final String POSITION = "POSITION";
        public static final String THREAD_INFO = "THREAD_INFO";
        public static final String MESSAGE_CODER_EXCEPTION = "MESSAGE_CODER_EXCEPTION";
        public static final String UNKNOWN_COMMAND_INFO = "UNKNOWN_COMMAND_INFO";
        public static final String SUSPENED_THREADS = "SUSPENED_THREADS";
        public static final String NEW_MODEL = "NEW_MODEL";
        public static final String INFO = "INFO";
    }
    
}
