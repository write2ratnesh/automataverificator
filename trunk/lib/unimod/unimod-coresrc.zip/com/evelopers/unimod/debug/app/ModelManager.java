package com.evelopers.unimod.debug.app;

import com.evelopers.unimod.core.stateworks.Model;
import com.evelopers.unimod.debug.Params;
import com.evelopers.unimod.runtime.ControlledObject;
import com.evelopers.unimod.runtime.context.StateMachineContext;

public class ModelManager implements ControlledObject {

	private Model newModel;

	/**
	 * @unimod.action.descr store new model for futher update
	 */
	public void z1(StateMachineContext context) {
		newModel = (Model)context.getEventContext().getParameter(Params.Event.NEW_MODEL);
	}

	Model getNewModel() {
		return newModel;
	}

	void setNewModel(Model newModel) {
		this.newModel = newModel;
	}
	
}
